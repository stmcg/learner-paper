#' Cross-validation for LEARNER
#'
#' This function performs k-fold cross-validation to select the nuisance parameters \eqn{(\lambda_1, \lambda_2)} for \code{\link{learner}}.
#'
#' @param Y_target matrix containing the target population data, as in \code{\link{learner}}
#' @param Y_source matrix or list of matrices (multiple source populations), as in \code{\link{learner}}
#' @param source_weights (optional) numeric vector of weights for each source when \code{Y_source} is a list, as in \code{\link{learner}}
#' @param r_target (optional) integer specifying the rank of the target population knowledge graph, as in \code{\link{learner}}.
#' @param r_source (optional) integer specifying the rank used to define the latent spaces in the source population during cross-validation.
#' @param lambda_1_all vector of numerics specifying candidate values of \eqn{\lambda_1} when row and column penalties are tied (same as \code{learner}'s \code{lambda_1}). Do not use together with \code{lambda_1_row_all} and \code{lambda_1_col_all}.
#' @param lambda_2_all vector of numerics specifying the candidate values of \eqn{\lambda_2} (see Details)
#' @param lambda_1_row_all (optional) vector of candidate \eqn{\lambda_{1,1}} values for the row/genotypic subspace penalty. Must be used with \code{lambda_1_col_all}; implies a 3D grid with \code{lambda_2_all}.
#' @param lambda_1_col_all (optional) vector of candidate \eqn{\lambda_{1,2}} values for the column/phenotypic subspace penalty. Must be used with \code{lambda_1_row_all}.
#' @param step_size numeric scalar specifying the step size for the Newton steps in the numerical optimization algorithm, as in \code{\link{learner}}
#' @param n_folds an integer specify the number of cross-validation folds. The default is \code{4}.
#' @param n_cores an integer specifying the number of CPU cores in parallelization. Parallelization is performed across the different candidate \eqn{(\lambda_1, \lambda_2)} pairs. The default is \code{1}, i.e., no parallelization.
#' @param control a list of parameters for controlling the stopping criteria for the numerical optimization algorithm, as in \code{\link{learner}}.
#'
#' @return A list with the following elements:
#' \item{lambda_1_min}{value of \eqn{\lambda_1} with the smallest MSE in tied mode; \code{NA} in separate-penalty mode}
#' \item{lambda_2_min}{value of \eqn{\lambda_2} with the smallest MSE}
#' \item{lambda_1_row_min}{(separate mode only) selected \eqn{\lambda_{1,1}}; \code{NA} in tied mode}
#' \item{lambda_1_col_min}{(separate mode only) selected \eqn{\lambda_{1,2}}; \code{NA} in tied mode}
#' \item{mse_all}{In tied mode, a matrix of MSE for each \eqn{(\lambda_1, \lambda_2)} pair (rows: \eqn{\lambda_1}, columns: \eqn{\lambda_2}). In separate mode, a 3D array with dimensions corresponding to \code{lambda_1_row_all}, \code{lambda_1_col_all}, and \code{lambda_2_all}.}
#' \item{r}{rank value used.}
#'
#' @details
#' Given sets of candidate values of \eqn{\lambda_1} and \eqn{\lambda_2}, this function performs k-fold cross-validation to select the pair \eqn{(\lambda_1, \lambda_2)} with the smallest held out error. This function randomly partitions the entries of \code{Y_target} into \eqn{k} (approximately) equally sized subsamples. The training data sets are obtained by removing one of the \eqn{k} subsamples and the corresponding test data sets are based on the held out subsamples. The \code{\link{learner}} function is applied to each training data set. The held out error is computed by the mean squared error comparing the entries in the test data sets with those imputed from the LEARNER estimates. See McGrath et al. (2024) for further details.
#'
#' @references
#' McGrath, S., Zhu, C,. Guo, M. and Duan, R. (2024). \emph{LEARNER: A transfer learning method for low-rank matrix estimation}. arXiv preprint	arXiv:2412.20605.
#'
#' @examples
#' res <- cv.learner(Y_source = dat_highsim$Y_source,
#'                   Y_target = dat_highsim$Y_target,
#'                   lambda_1_all = c(1, 10, 100),
#'                   lambda_2_all = c(1, 10, 100),
#'                   step_size = 0.003)
#'
#'
#' @import foreach
#' @import doParallel
#'
#' @export



cv.learner <- function(Y_source, Y_target, r_target, lambda_1_all = NULL, lambda_2_all,
                       step_size, n_folds = 4, n_cores = 1, control = list(),
                       r_source,
                       source_weights = NULL,
                       lambda_1_row_all = NULL, lambda_1_col_all = NULL){

  ## Normalize Y_source: matrix or list of matrices (rank from first)
  is_list <- is.list(Y_source) && !is.matrix(Y_source)
  if (is_list){
    if (length(Y_source) < 1L) stop('Y_source list must have at least one element.')
    Y_ref <- Y_source[[1]]
    if (!is.matrix(Y_ref)) stop('Each element of Y_source must be a matrix.')
    for (k in seq_along(Y_source)){
      if (!identical(dim(Y_source[[k]]), dim(Y_target)))
        stop('All source matrices and Y_target must have the same dimensions.')
      if (any(is.na(Y_source[[k]])))
        stop('Source matrices cannot contain NA values.')
    }
    if (!is.null(source_weights)){
      if (length(source_weights) != length(Y_source))
        stop('source_weights must have length equal to the number of sources.')
      source_weights <- as.numeric(source_weights) / sum(source_weights)
    }
  } else {
    Y_ref <- Y_source
    if (!identical(dim(Y_source), dim(Y_target)))
      stop('Y_source and Y_target must have the same dimensions')
    if (any(is.na(Y_source)))
      stop('Y_source cannot have NA values.')
  }

  p <- nrow(Y_ref)
  q <- ncol(Y_ref)

  both_missing <- missing(r_target) && missing(r_source)

  if (both_missing){
    max_rank <- min(p, q) / 3
    r_hat <- max(ScreeNOT::adaptiveHardThresholding(Y = Y_ref, k = max_rank)$r, 1)
    r_source <- r_hat
    r_target <- r_hat
  } else {
    if (missing(r_source)){
      max_rank <- min(p, q) / 3
      r_source <- max(ScreeNOT::adaptiveHardThresholding(Y = Y_ref, k = max_rank)$r, 1)
    }
    if (missing(r_target)){
      if (any(is.na(Y_target))){
        r_target <- r_source
      } else {
        max_rank <- min(p, q) / 3
        r_target <- max(ScreeNOT::adaptiveHardThresholding(Y = Y_target, k = max_rank)$r, 1)
      }
    }
  }
  if (!('max_iter' %in% names(control))){
    control$max_iter <- 100
  }
  if (!('threshold' %in% names(control))){
    control$threshold <- 0.001
  }
  if (!('max_value' %in% names(control))){
    control$max_value <- 10
  }

  r_svd_source <- max(r_source, r_target)
  if (r_svd_source > min(p, q)){
    stop('max(r_source, r_target) cannot exceed min(nrow(Y_source), ncol(Y_source)).')
  }

  ## Build U_basis_list and V_basis_list; init from first source
  if (is_list){
    U_basis_list <- vector('list', length(Y_source))
    V_basis_list <- vector('list', length(Y_source))
    for (k in seq_along(Y_source)){
      svd_k <- svd(Y_source[[k]], nu = r_svd_source, nv = r_svd_source)
      U_basis_list[[k]] <- svd_k$u[, 1:r_source, drop = FALSE]
      V_basis_list[[k]] <- svd_k$v[, 1:r_source, drop = FALSE]
    }
    svd_first <- svd(Y_source[[1]], nu = r_svd_source, nv = r_svd_source)
  } else {
    svd_first <- svd(Y_source, nu = r_svd_source, nv = r_svd_source)
    U_basis_list <- list(svd_first$u[, 1:r_source, drop = FALSE])
    V_basis_list <- list(svd_first$v[, 1:r_source, drop = FALSE])
  }

  d_first <- svd_first$d
  U_init <- svd_first$u[, 1:r_target, drop = FALSE] %*%
    diag(sqrt(d_first[1:r_target]), nrow = r_target, ncol = r_target)
  V_init <- svd_first$v[, 1:r_target, drop = FALSE] %*%
    diag(sqrt(d_first[1:r_target]), nrow = r_target, ncol = r_target)

  if (n_folds < 2){
    stop('n_folds must be 2 or greater.')
  }

  separate_cv <- !is.null(lambda_1_row_all) && !is.null(lambda_1_col_all)
  if (separate_cv){
    if (!is.null(lambda_1_all)){
      stop('Do not use lambda_1_all together with lambda_1_row_all and lambda_1_col_all.')
    }
    n_lambda_1_row <- length(lambda_1_row_all)
    n_lambda_1_col <- length(lambda_1_col_all)
    if (n_lambda_1_row < 1L || n_lambda_1_col < 1L){
      stop('lambda_1_row_all and lambda_1_col_all must each have length at least 1.')
    }
  } else {
    if (!is.null(lambda_1_row_all) || !is.null(lambda_1_col_all)){
      stop('Provide both lambda_1_row_all and lambda_1_col_all for separate row/column penalties, or use lambda_1_all for tied penalties.')
    }
    if (is.null(lambda_1_all)){
      stop('Provide lambda_1_all (tied penalties) or both lambda_1_row_all and lambda_1_col_all.')
    }
    n_lambda_1 <- length(lambda_1_all)
  }
  n_lambda_2 <- length(lambda_2_all)

  ## Creating training and testing data sets
  available_indices <- 1:(p * q)
  available_indices <- available_indices[!(available_indices %in% which(is.na(Y_target)))]
  n_indices <- length(available_indices)
  indices <- sample(available_indices, size = n_indices, replace = FALSE)

  index_set <- vector(mode = "list", length = n_folds)
  for (fold in 1:n_folds){
    index_set[[fold]] <- indices[floor((fold - 1) * n_indices / n_folds + 1):floor(fold * n_indices / n_folds)]
  }

  ## Applying LEARNER for each candidate penalty grid
  if (!separate_cv){
    ## Tied lambda_1 for row and column (2D grid)
    if (n_cores > 1){
      registerDoParallel(cores = n_cores)
      mse_all <- foreach(lambda_1_ind = 1:n_lambda_1, .combine = 'cbind') %:%
        foreach(lambda_2_ind = 1:n_lambda_2, .combine = 'c') %dopar% {
          cv.learner_helper(Y_target = Y_target, index_set = index_set, n_folds = n_folds,
                            lambda1_row = lambda_1_all[lambda_1_ind], lambda1_col = lambda_1_all[lambda_1_ind],
                            lambda2 = lambda_2_all[lambda_2_ind],
                            U_init = U_init, V_init = V_init,
                            U_basis_list = U_basis_list, V_basis_list = V_basis_list, source_weights = source_weights, step_size = step_size,
                            control = control)
        }
    } else {
      mse_all <- foreach(lambda_1_ind = 1:n_lambda_1, .combine = 'cbind') %:%
        foreach(lambda_2_ind = 1:n_lambda_2, .combine = 'c') %do% {
          cv.learner_helper(Y_target = Y_target, index_set = index_set, n_folds = n_folds,
                            lambda1_row = lambda_1_all[lambda_1_ind], lambda1_col = lambda_1_all[lambda_1_ind],
                            lambda2 = lambda_2_all[lambda_2_ind],
                            U_init = U_init, V_init = V_init,
                            U_basis_list = U_basis_list, V_basis_list = V_basis_list, source_weights = source_weights, step_size = step_size,
                            control = control)
        }
    }
    mse_all <- t(mse_all)

    min_ind <- which(mse_all == min(mse_all, na.rm = TRUE), arr.ind = TRUE)
    lambda_1_min <- lambda_1_all[min_ind[1]]
    lambda_2_min <- lambda_2_all[min_ind[2]]

    return(list(
      lambda_1_min = lambda_1_min,
      lambda_2_min = lambda_2_min,
      lambda_1_row_min = NA_real_,
      lambda_1_col_min = NA_real_,
      mse_all = mse_all,
      r = r_target
    ))
  }

  ## Separate row/column penalties (3D grid)
  grid <- expand.grid(
    lambda_1_row_ind = seq_len(n_lambda_1_row),
    lambda_1_col_ind = seq_len(n_lambda_1_col),
    lambda_2_ind = seq_len(n_lambda_2)
  )
  n_grid <- nrow(grid)
  if (n_cores > 1){
    registerDoParallel(cores = n_cores)
    mse_vec <- foreach(g = seq_len(n_grid), .combine = 'c') %dopar% {
      ir <- grid$lambda_1_row_ind[g]
      ic <- grid$lambda_1_col_ind[g]
      i2 <- grid$lambda_2_ind[g]
      cv.learner_helper(Y_target = Y_target, index_set = index_set, n_folds = n_folds,
                        lambda1_row = lambda_1_row_all[ir], lambda1_col = lambda_1_col_all[ic],
                        lambda2 = lambda_2_all[i2],
                        U_init = U_init, V_init = V_init,
                        U_basis_list = U_basis_list, V_basis_list = V_basis_list, source_weights = source_weights, step_size = step_size,
                        control = control)
    }
  } else {
    mse_vec <- foreach(g = seq_len(n_grid), .combine = 'c') %do% {
      ir <- grid$lambda_1_row_ind[g]
      ic <- grid$lambda_1_col_ind[g]
      i2 <- grid$lambda_2_ind[g]
      cv.learner_helper(Y_target = Y_target, index_set = index_set, n_folds = n_folds,
                        lambda1_row = lambda_1_row_all[ir], lambda1_col = lambda_1_col_all[ic],
                        lambda2 = lambda_2_all[i2],
                        U_init = U_init, V_init = V_init,
                        U_basis_list = U_basis_list, V_basis_list = V_basis_list, source_weights = source_weights, step_size = step_size,
                        control = control)
    }
  }
  mse_all <- array(mse_vec, dim = c(n_lambda_1_row, n_lambda_1_col, n_lambda_2))

  min_ind <- which(mse_all == min(mse_all, na.rm = TRUE), arr.ind = TRUE)[1L, , drop = FALSE]
  lambda_1_row_min <- lambda_1_row_all[min_ind[1, 1]]
  lambda_1_col_min <- lambda_1_col_all[min_ind[1, 2]]
  lambda_2_min <- lambda_2_all[min_ind[1, 3]]

  return(list(
    lambda_1_min = NA_real_,
    lambda_2_min = lambda_2_min,
    lambda_1_row_min = lambda_1_row_min,
    lambda_1_col_min = lambda_1_col_min,
    mse_all = mse_all,
    r = r_target
  ))
}

cv.learner_helper <- function(Y_target, index_set, n_folds,
                              lambda1_row, lambda1_col, lambda2,
                              U_init, V_init, U_basis_list, V_basis_list, source_weights,
                              step_size, control){
  norm_temp <- 0
  p <- nrow(Y_target); q <- ncol(Y_target)
  for (fold in 1:n_folds){
    Y_training <- Y_target
    myset <- index_set[[fold]]
    Y_training[myset] <- NA
    perc_nonmissing <- sum(!is.na(Y_training)) / (p * q)

    fit <- try(learner_helper(theta_hat = Y_training,
                              lambda1_row = lambda1_row,
                              lambda1_col = lambda1_col,
                              lambda2 = lambda2,
                              U_init = U_init, V_init = V_init,
                              U_basis_list = U_basis_list, V_basis_list = V_basis_list, source_weights = source_weights, missing = TRUE,
                              perc_nonmissing = perc_nonmissing,
                              step_size = step_size, control = control))
    if ('try-error' %in% class(fit)){
      return(NA)
    } else {
      norm_temp <- norm_temp + sum((fit$learner_estimate[myset] - Y_target[myset])^2)
    }
  }
  return(norm_temp)
}
