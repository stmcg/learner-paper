#' Latent space-based transfer learning
#'
#' This function applies the LatEnt spAce-based tRaNsfer lEaRning (LEARNER) method (McGrath et al. 2024) to leverage data from a source population to improve
#' estimation of a low rank matrix in an underrepresented target population.
#'
#' @param Y_target matrix containing the target population data
#' @param Y_source matrix of size \eqn{p \times q}, or a list of such matrices (multiple source populations). If a list, rank is determined from the first element and the latent spaces are combined across sources (see Details).
#' @param source_weights (optional) numeric vector of weights for each source when \code{Y_source} is a list. Must have length equal to the number of sources; will be normalized to sum to 1. If \code{NULL}, equal weights are used.
#' @param r_target (optional) integer specifying the rank of the target population knowledge graph.
#' @param r_source (optional) integer specifying the rank used to define the latent spaces in the source population.
#' @param lambda_1 numeric scalar specifying the value of \eqn{\lambda_1} when the same penalty is used for row- and column-space mismatch (tied mode). Ignored if \code{lambda_1_row} and \code{lambda_1_col} are both provided.
#' @param lambda_2 numeric scalar specifying the value of \eqn{\lambda_2} (see Details)
#' @param lambda_1_row (optional) numeric scalar \eqn{\lambda_{1,1}} for the latent row/genotypic subspace penalty. If \code{NULL} (default), tied mode uses \code{lambda_1} for both row and column penalties.
#' @param lambda_1_col (optional) numeric scalar \eqn{\lambda_{1,2}} for the latent column/phenotypic subspace penalty. If \code{NULL} (default), tied mode uses \code{lambda_1} for both row and column penalties.
#' @param step_size numeric scalar specifying the step size for the Newton steps in the numerical optimization algorithm
#' @param control a list of parameters for controlling the stopping criteria for the numerical optimization algorithm. The list may include the following components:
#' \tabular{ll}{
#' \code{max_iter} \tab integer specifying the maximum number of iterations \cr
#' \code{threshold} \tab numeric scalar specifying a convergence threshold. The algorithm converges when \eqn{|\epsilon_t - \epsilon_{t-1}| < }\code{threshold}, where \eqn{\epsilon_t} denotes the value of the objective function at iteration \eqn{t}. \cr
#' \code{max_value} \tab numeric scalar used to specify the maximum value of the objective function allowed before terminating the algorithm. Specifically, the algorithm will terminate if the value of the objective function exceeds \code{max_value}\eqn{\times \epsilon_0}, where \eqn{\epsilon_0} denotes the value of the objective function at the initial point. This is used to prevent unnecessary computation time after the optimization algorithm diverges. \cr}
#'
#' @return A list with the following elements:
#' \item{learner_estimate}{matrix containing the LEARNER estimate of the target population knowledge graph}
#' \item{objective_values}{numeric vector containing the values of the objective function at each iteration}
#' \item{convergence_criterion}{integer specifying the criterion that was satisfied for terminating the numerical optimization algorithm. A value of 1 indicates the convergence threshold was satisfied; A value of 2 indicates that the maximum number of iterations was satisfied; A value of 3 indicates that the maximum value of the objective function was satisfied.}
#' \item{r}{rank value used.}
#'
#' @details
#'
#' \strong{Data and notation:}
#'
#' The data consists of a matrix in the target population \eqn{Y_0 \in \mathbb{R}^{p \times q}} and the source population \eqn{Y_1 \in \mathbb{R}^{p \times q}}.
#' Let \eqn{\hat{U}_{k} \hat{\Lambda}_{k} \hat{V}_{k}^{\top}} denote the truncated singular value decomposition (SVD) of \eqn{Y_k}, \eqn{k = 0, 1}.
#'
#' When \code{Y_source} is a list of matrices (multiple source populations), rank is determined from the first element \code{Y_source[[1]]} only. The penalty terms use a weighted combination of the latent row and column spaces: \eqn{\mathcal{P}_{\perp}} is replaced by \eqn{I - \sum_k w_k \hat{U}_k \hat{U}_k'} (and similarly for \eqn{V}), where \eqn{\hat{U}_k} comes from the rank-\eqn{r} SVD of the \eqn{k}th source and \eqn{w_k} are the \code{source_weights} (normalized to sum to 1; equal weights if \code{source_weights} is \code{NULL}). These combinations are applied without forming full projectors.
#'
#' The working ranks \code{r_source} and \code{r_target} can differ. When both are missing, ScreeNOT (Donoho et al. 2023) is applied to the first source (or the single source) and the resulting rank is used for both \code{r_source} and \code{r_target}. Otherwise:
#' \enumerate{
#'   \item If \code{r_source} is missing, ScreeNOT is applied to the first source to estimate \code{r_source}.
#'   \item If \code{r_target} is missing, ScreeNOT is applied to \code{Y_target} to estimate \code{r_target}. If \code{Y_target} contains missing values, \code{r_target} defaults to \code{r_source}.
#' }
#'
#' For \eqn{k = 0, 1}, one can view \eqn{Y_k} as a noisy version of \eqn{\Theta_k}, referred to as the knowledge graph. The target of inference is the target population knowledge graph, \eqn{\Theta_0}.
#'
#' \strong{Estimation:}
#'
#' This method estimates \eqn{\Theta_0} by \eqn{\tilde{U}\tilde{V}^{\top}}, where \eqn{(\tilde{U}, \tilde{V})} is the solution to the following optimization problem
#' \deqn{\mathrm{arg\,min}_{U \in \mathbb{R}^{p \times r}, V \in \mathbb{R}^{q \times r}} \big\{ \| U V^{\top} - Y_0 \|_F^2 + \lambda_1\| \mathcal{P}_{\perp}(\hat{U}_{1})U \|_F^2 + \lambda_1\|  \mathcal{P}_{\perp}(\hat{V}_{1})V \|_F^2  + \lambda_2 \| U^{\top} U - V^{\top} V \|_F^2 \big\}}
#' where \eqn{\mathcal{P}_{\perp}(\hat{U}_{1}) = I - \hat{U}_{1}^{\top}\hat{U}_{1}} and \eqn{\mathcal{P}_{\perp}(\hat{V}_{1}) = I - \hat{V}_{1}^{\top}\hat{V}_{1}}.
#'
#' This function uses an alternating minimization strategy to solve the optimization problem. That is, this approach updates \eqn{U} by minimizing the objective function (via a gradient descent step) treating \eqn{V} as fixed. Then, \eqn{V} is updated treating \eqn{U} as fixed. These updates of \eqn{U} and \eqn{V} are repeated until convergence.
#'
#' @references
#' McGrath, S., Zhu, C,. Guo, M. and Duan, R. (2024). \emph{LEARNER: A transfer learning method for low-rank matrix estimation}. arXiv preprint	arXiv:2412.20605.
#'
#' Donoho, D., Gavish, M. and Romanov, E. (2023). \emph{ScreeNOT: Exact MSE-optimal singular value thresholding in correlated noise}. The Annals of Statistics, 51(1), pp.122-148.
#'
#' @examples
#' res <- learner(Y_source = dat_highsim$Y_source,
#'                Y_target = dat_highsim$Y_target,
#'                lambda_1 = 1, lambda_2 = 1,
#'                step_size = 0.003)
#'
#' @export
learner <- function(Y_source, Y_target, r_target, lambda_1 = NULL, lambda_2, step_size,
                    r_source,
                    source_weights = NULL,
                    control = list(),
                    lambda_1_row = NULL, lambda_1_col = NULL){
  ## Normalize Y_source: matrix or list of matrices
  is_list <- is.list(Y_source) && !is.matrix(Y_source)
  if (is_list){
    if (length(Y_source) < 1L) stop('Y_source list must have at least one element.')
    Y_ref <- Y_source[[1]]
    if (!is.matrix(Y_ref)) stop('Each element of Y_source must be a matrix.')
    for (k in seq_along(Y_source)){
      if (!identical(dim(Y_source[[k]]), dim(Y_target)))
        stop('All source matrices and Y_target must have the same dimensions.')
      if (any(is.na(Y_source[[k]])))
        stop('Source matrices cannot contain NA values.')
    }
    if (!is.null(source_weights)){
      if (length(source_weights) != length(Y_source))
        stop('source_weights must have length equal to the number of sources.')
      source_weights <- as.numeric(source_weights) / sum(source_weights)
    }
  } else {
    Y_ref <- Y_source
    if (!identical(dim(Y_source), dim(Y_target)))
      stop('Y_source and Y_target must have the same dimensions')
    if (any(is.na(Y_source)))
      stop('Y_source cannot have NA values.')
  }
  ## Tied vs separate row/column penalties (supplement: lambda_{1,1}, lambda_{1,2})
  if (!is.null(lambda_1_row) && !is.null(lambda_1_col)){
    if (!is.null(lambda_1)){
      stop('Provide either lambda_1 (tied penalties) or lambda_1_row and lambda_1_col (separate), not both.')
    }
    if (length(lambda_1_row) > 1){
      stop('lambda_1_row must be a scalar. See cv.learner for selecting values.')
    }
    if (length(lambda_1_col) > 1){
      stop('lambda_1_col must be a scalar. See cv.learner for selecting values.')
    }
    lambda1_row <- lambda_1_row
    lambda1_col <- lambda_1_col
  } else if (is.null(lambda_1_row) && is.null(lambda_1_col)){
    if (is.null(lambda_1)){
      stop('lambda_1 must be provided when lambda_1_row and lambda_1_col are not both set.')
    }
    if (length(lambda_1) > 1){
      stop('lambda_1 must be a scalar. See the function cv.learner for selecting a suitable lambda_1 value.')
    }
    lambda1_row <- lambda_1
    lambda1_col <- lambda_1
  } else {
    stop('Both lambda_1_row and lambda_1_col must be provided together, or use lambda_1 alone (tied mode).')
  }
  if (length(lambda_2) > 1){
    stop('lambda_2 must be a scalar. See the function cv.learner for selecting a suitable lambda_2 value.')
  }

  ## Setting the rank and other parameters (rank from first source)
  missing <- any(is.na(Y_target))
  p <- nrow(Y_ref)
  q <- ncol(Y_ref)
  perc_nonmissing <- sum(!is.na(Y_target)) / (p * q)

  both_missing <- missing(r_target) && missing(r_source)

  if (both_missing){
    max_rank <- min(p, q) / 3
    r_hat <- max(ScreeNOT::adaptiveHardThresholding(Y = Y_ref, k = max_rank)$r, 1)
    r_source <- r_hat
    r_target <- r_hat
  } else {
    if (missing(r_source)){
      max_rank <- min(p, q) / 3
      r_source <- max(ScreeNOT::adaptiveHardThresholding(Y = Y_ref, k = max_rank)$r, 1)
    }
    if (missing(r_target)){
      if (any(is.na(Y_target))){
        r_target <- r_source
      } else {
        max_rank <- min(p, q) / 3
        r_target <- max(ScreeNOT::adaptiveHardThresholding(Y = Y_target, k = max_rank)$r, 1)
      }
    }
  }

  if (!('max_iter' %in% names(control))){
    control$max_iter <- 100
  }
  if (!('threshold' %in% names(control))){
    control$threshold <- 0.001
  }
  if (!('max_value' %in% names(control))){
    control$max_value <- 10
  }

  r_svd_source <- max(r_source, r_target)
  if (r_svd_source > min(p, q)){
    stop('max(r_source, r_target) cannot exceed min(nrow(Y_source), ncol(Y_source)).')
  }

  ## Build U_basis_list and V_basis_list; init from first source
  if (is_list){
    U_basis_list <- vector('list', length(Y_source))
    V_basis_list <- vector('list', length(Y_source))
    for (k in seq_along(Y_source)){
      svd_k <- svd(Y_source[[k]], nu = r_svd_source, nv = r_svd_source)
      U_basis_list[[k]] <- svd_k$u[, 1:r_source, drop = FALSE]
      V_basis_list[[k]] <- svd_k$v[, 1:r_source, drop = FALSE]
    }
    svd_first <- svd(Y_source[[1]], nu = r_svd_source, nv = r_svd_source)
  } else {
    svd_first <- svd(Y_source, nu = r_svd_source, nv = r_svd_source)
    U_basis_list <- list(svd_first$u[, 1:r_source, drop = FALSE])
    V_basis_list <- list(svd_first$v[, 1:r_source, drop = FALSE])
  }

  d_first <- svd_first$d
  U_init <- svd_first$u[, 1:r_target, drop = FALSE] %*%
    diag(sqrt(d_first[1:r_target]), nrow = r_target, ncol = r_target)
  V_init <- svd_first$v[, 1:r_target, drop = FALSE] %*%
    diag(sqrt(d_first[1:r_target]), nrow = r_target, ncol = r_target)

  out <- learner_helper(control = control, U_init = U_init, V_init = V_init, lambda1_row = lambda1_row,
                        lambda1_col = lambda1_col,
                        lambda2 = lambda_2, theta_hat = Y_target, U_basis_list = U_basis_list, V_basis_list = V_basis_list, source_weights = source_weights, missing = missing,
                        perc_nonmissing = perc_nonmissing, step_size = step_size)

  return(out)
}

learner_helper <- function(control, U_init, V_init, lambda1_row, lambda1_col, lambda2, theta_hat, U_basis_list, V_basis_list, source_weights, missing,
                           perc_nonmissing, step_size){
  U <- U_init
  V <- V_init
  max_iter <- control$max_iter
  threshold <- control$threshold
  max_value <- control$max_value

  obj_func_init <- f(U = U, V = V, lambda1_row = lambda1_row, lambda1_col = lambda1_col, lambda2 = lambda2, theta_hat = theta_hat, U_basis_list = U_basis_list, V_basis_list = V_basis_list, source_weights = source_weights, missing = missing,
                     perc_nonmissing = perc_nonmissing)
  obj_func_best <- obj_func_init; U_best <- U; V_best <- V
  obj_func <- rep(NA, times = max_iter)
  U_norm <- norm(U, type = 'F')
  V_norm <- norm(V, type = 'F')

  for (iter in 1:max_iter){
    f_delta_U <- f_prime_u(U = U, V = V, lambda1_row = lambda1_row, lambda2 = lambda2, theta_hat = theta_hat, U_basis_list = U_basis_list, source_weights = source_weights, missing = missing, perc_nonmissing = perc_nonmissing)
    f_delta_V <- f_prime_v(U = U, V = V, lambda1_col = lambda1_col, lambda2 = lambda2, theta_hat = theta_hat, V_basis_list = V_basis_list, source_weights = source_weights, missing = missing, perc_nonmissing = perc_nonmissing)

    f_delta_U_norm <- norm(f_delta_U, type = 'F')
    f_delta_V_norm <- norm(f_delta_V, type = 'F')

    U <- U - (step_size * U_norm / f_delta_U_norm) * f_delta_U
    V <- V - (step_size * V_norm / f_delta_V_norm) * f_delta_V

    obj_func[iter] <- f(U = U, V = V, lambda1_row = lambda1_row, lambda1_col = lambda1_col, lambda2 = lambda2, theta_hat = theta_hat, U_basis_list = U_basis_list, V_basis_list = V_basis_list, source_weights = source_weights, missing = missing, perc_nonmissing = perc_nonmissing)
    if (obj_func[iter] < obj_func_best){
      obj_func_best <- obj_func[iter]; U_best <- U; V_best <- V
    }
    if (iter > 1){
      if (abs(obj_func[iter] - obj_func[iter - 1]) < threshold){
        convergence_criterion <- 1
        break()
      }
      if (obj_func[iter] > max_value * obj_func_init){
        convergence_criterion <- 3
        break()
      }
    }
    U_norm <- norm(U, type = 'F')
    V_norm <- norm(V, type = 'F')

    if (iter == max_iter){
      convergence_criterion <- 2
    }
  }
  theta_hat <- U_best %*% t(V_best)
  return(list(learner_estimate = theta_hat, objective_values = obj_func,
              convergence_criterion = convergence_criterion,
              r = ncol(U)))
}


norm_2_sq <- function(x){
  return(sum(x^2))
}

## Apply (I - sum_k w_k basis_k basis_k') to A without forming projectors.
## basis_list: list of matrices. weights: optional length-K vector (normalized to sum to 1).
apply_P_perp_basis_list <- function(basis_list, A, weights = NULL){
  K <- length(basis_list)
  if (K == 0L) return(A)
  if (is.null(weights)) weights <- rep(1 / K, K)
  weights <- as.numeric(weights) / sum(weights)
  proj_sum <- Reduce('+', mapply(function(Bk, wk) wk * (Bk %*% crossprod(Bk, A)), basis_list, weights, SIMPLIFY = FALSE))
  A - proj_sum
}

f <- function(U, V, lambda1_row, lambda1_col, lambda2, theta_hat, U_basis_list, V_basis_list, source_weights, missing, perc_nonmissing){
  if (missing){
    t1 <- sum((U %*% t(V) - theta_hat)^2, na.rm = TRUE) / perc_nonmissing
  } else {
    t1 <- norm(U %*% t(V) - theta_hat, type = 'F')^2 / perc_nonmissing
  }
  P_perp_U <- apply_P_perp_basis_list(U_basis_list, U, source_weights)
  P_perp_V <- apply_P_perp_basis_list(V_basis_list, V, source_weights)
  t2 <- lambda1_row * norm(P_perp_U, type = 'F')^2
  t3 <- lambda1_col * norm(P_perp_V, type = 'F')^2
  t4 <- lambda2 * norm(t(U) %*% U - t(V) %*% V, type = 'F')^2
  return(t1 + t2 + t3 + t4)
}

f_prime_u <- function(U, V, lambda1_row, lambda2, theta_hat, U_basis_list, source_weights, missing, perc_nonmissing){
  U_tilde <- t(U) %*% U
  V_tilde <- t(V) %*% V

  if (missing){
    temp <- U %*% t(V)
    missing_entries <- which(is.na(theta_hat), arr.ind = T)
    theta_hat[missing_entries] <- temp[missing_entries]
  }
  t1 <- (2 / perc_nonmissing) * (U %*% V_tilde - theta_hat %*% V)
  P_perp_U <- apply_P_perp_basis_list(U_basis_list, U, source_weights)
  t2 <- lambda1_row * 2 * apply_P_perp_basis_list(U_basis_list, P_perp_U, source_weights)
  t4 <- lambda2 * 4 * U %*% (U_tilde - V_tilde)
  return(t1 + t2 + t4)
}

f_prime_v <- function(U, V, lambda1_col, lambda2, theta_hat, V_basis_list, source_weights, missing, perc_nonmissing){
  U_tilde <- t(U) %*% U
  V_tilde <- t(V) %*% V

  if (missing){
    temp <- U %*% t(V)
    missing_entries <- which(is.na(theta_hat), arr.ind = T)
    theta_hat[missing_entries] <- temp[missing_entries]
  }
  t1 <- (2 / perc_nonmissing) * (V %*% U_tilde - t(theta_hat) %*% U)
  P_perp_V <- apply_P_perp_basis_list(V_basis_list, V, source_weights)
  t3 <- lambda1_col * 2 * apply_P_perp_basis_list(V_basis_list, P_perp_V, source_weights)
  t4 <- lambda2 * 4 * V %*% (V_tilde - U_tilde)
  return(t1 + t3 + t4)
}
