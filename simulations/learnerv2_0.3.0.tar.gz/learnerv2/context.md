# Project Context

This repository contains an R package that implements latent-space transfer learning methods for low-rank matrix estimation. The package's main user-facing goal is to improve estimation of a low-rank *target* matrix by leveraging similarity between the latent row/column spaces of a *source* population (or multiple source populations) and the target population.

The paper's setting is a two-population model in which population matrices satisfy `Y_k = Theta_k + Z_k` for `k = 0` (target) and `k = 1` (source). The signal matrices `Theta_k` are assumed low rank and admit a factorization `Theta_k = U_k V_k^T`, where the column spaces of `U_k` (row/'genotypic' latent factors) and `V_k` (column/'phenotypic' latent factors) form the latent subspaces that LEARNER uses for transfer.

## Package Overview

- Package name in `DESCRIPTION`: `learnerv2`
- Version: `0.2.0`
- Title: *Latent Space-Based Transfer Learning*
- License: GPL (>= 3)
- Main methods are described in McGrath et al. (2024), including:
  - `learner()` (LEARNER): latent space-based transfer with tunable nuisance parameters.
  - `dlearner()` (D-LEARNER): a direct projection variant with a stronger set of assumptions.
  - `cv.learner()`: cross-validation to select the tuning parameters for `learner()`.

Notes on naming: the README content (rendered from `README.Rmd`) refers to the package as `learner`, while the package metadata and tests refer to `learnerv2`. The exported API is defined by `NAMESPACE`.

## Exported API

The package exports the following functions (from `NAMESPACE`):

- `learner()` (`R/learner.R`)
- `dlearner()` (`R/dlearner.R`)
- `cv.learner()` (`R/cv_learner.R`)

### `learner()`: Latent Space-Based Transfer Learning

`learner(Y_source, Y_target, lambda_1, lambda_2, step_size, ...)` implements the paper's LEARNER estimator. It estimates the target signal `Theta_0` (corresponding to `Y_target`) by solving the penalized low-rank problem over factors `U` and `V`:

`min_{U in R^{p x r}, V in R^{q x r}} { ||U V^T - Y_target||_F^2`
+ `lambda_1 * || P_perp(U_hat_1) U ||_F^2`
+ `lambda_1 * || P_perp(V_hat_1) V ||_F^2`
+ `lambda_2 * ||U^T U - V^T V||_F^2 }`

Here `U_hat_1` and `V_hat_1` are rank-`r` truncated SVD subspace estimates learned from the source `Y_source` (corresponding to `Y_1`), and `P_perp(A) = I - A A^T` denotes projection onto the orthogonal complement of the source latent subspace. The second and third penalty terms are the transfer-learning mechanism: they penalize mismatch between the target's latent row/column subspaces and the source's latent row/column subspaces, enabling borrowing when the subspaces are similar (and reducing negative transfer when they are not).

In the implementation:

- Inputs:
  - `Y_source`: either a single matrix or a list of matrices (multiple sources).
  - `Y_target`: target matrix (may include `NA` values).
  - `lambda_1`, `lambda_2`: scalars controlling (i) the strength of the latent-subspace mismatch penalties (`lambda_1`) and (ii) balance/scale stabilization between the `U` and `V` factors (`lambda_2`).
  - `r_source`, `r_target` (optional): working ranks. If both are missing, `ScreeNOT::adaptiveHardThresholding()` is applied to the first source to set both. If only one is missing, it is estimated similarly; if `Y_target` has missing values and `r_target` is missing, `r_target` defaults to `r_source`.
  - `source_weights` (optional): weights used when `Y_source` is a list; normalized to sum to 1.
  - `control` (optional): stopping criteria for the alternating optimization loop (`max_iter`, `threshold`, `max_value`).
  - `step_size`: step-size multiplier for the gradient-based updates.
- Data assumptions:
  - `Y_source` (or each element of the source list) must not contain `NA`s.
  - `Y_target` may contain `NA`s and missing values are handled by a standard "impute-from-current-fit" scheme: the objective/data-fit contribution is scaled by the fraction of non-missing entries, and missing entries are replaced by the current low-rank reconstruction when computing gradients.
- Core computations:
  - Initializes `U` and `V` from a truncated SVD of the first source.
  - Solves the non-convex objective using alternating updates (update `U` holding `V` fixed, then update `V` holding `U` fixed), tracking the objective value and retaining the best iterate.
  - For multiple sources, implements the paper's weighted projection idea by combining source projection information using `source_weights`.
- Output:
  - `learner_estimate`: fitted low-rank estimate of the target signal matrix.
  - `objective_values`: objective value at each iteration.
  - `convergence_criterion`: termination condition indicator.
  - `r`: rank used.

### `cv.learner()`: Cross-Validation for `lambda_1` and `lambda_2`

`cv.learner(Y_source, Y_target, lambda_1_all, lambda_2_all, step_size, n_folds = 4, n_cores = 1, ...)` implements the paper's entrywise k-fold cross-validation approach to select the nuisance parameters `(lambda_1, lambda_2)`. It partitions (non-missing) entries of `Y_target` (corresponding to `Y_0`) into `n_folds` held-out subsets and evaluates how well LEARNER trained on the remaining entries predicts the held-out values.

For each candidate pair `(lambda_1, lambda_2)` and each fold:

- The training set is formed by treating the held-out entries as missing (the same "impute-from-current-fit" logic used by `learner()` handles them).
- The held-out error is measured by mean squared error between the LEARNER estimate and the held-out entries.

The selected tuning parameters are the pair with the smallest averaged held-out MSE across folds. The implementation parallelizes evaluation over the grid of `(lambda_1, lambda_2)` values when `n_cores > 1`. As in the paper, the optimization in each fold scales the data-fit term by the fraction of non-missing entries, which keeps the relative weight of the fitting term comparable across folds and missingness levels.

### `dlearner()`: Direct Projection LEARNER (No Tuning Parameters)

`dlearner(Y_source, Y_target, source_weights = NULL, r)` implements the paper's D-LEARNER estimator. Under the stronger assumption that the latent row and column subspaces match across source and target (i.e., `P(U_0) = P(U_1)` and `P(V_0) = P(V_1)`), D-LEARNER is tuning-parameter free and estimates the target signal by directly projecting `Y_target` onto the latent spaces learned from `Y_source`:

`Theta_hat_0^{D-LEARNER} = P(U_hat_1) Y_target P(V_hat_1)`.

In the implementation, rank `r` can be provided or estimated from the first source using `ScreeNOT::adaptiveHardThresholding()` (consistent with the paper's rank-selection discussion). Like in LEARNER, multi-source support is implemented by combining source subspace information using `source_weights`.

Practical constraint in this implementation: `Y_target` must be fully observed (no `NA`s); if missing values are present, `dlearner()` errors.

Output is `dlearner_estimate` (the projected/reconstructed target matrix) and `r` (the rank used).

## Internal Helpers

`R/globals.R` contains small helper utilities (e.g., `utils::globalVariables(...)` to silence NOTE messages for specific internal symbols).

`R/learner.R` defines additional internal functions, including:

- the objective function and gradient-like components (`f`, `f_prime_u`, `f_prime_v`)
- linear algebra helpers for applying weighted orthogonal projections without explicitly constructing full projectors (`apply_P_perp_basis_list`)

## Toy Datasets Included in the Package

`R/data.R` defines two simulated datasets used in examples and tests:

- `dat_highsim`
  - High similarity between source and target latent spaces.
  - Provides:
    - `Y_source`, `Y_target`: observed noisy matrices.
    - `Theta_source`, `Theta_target`: underlying low-rank matrices (rank 3 in the documentation).
- `dat_modsim`
  - Moderate similarity between source and target latent spaces.
  - Provides the same components (`Y_source`, `Y_target`, `Theta_source`, `Theta_target`) with a more perturbed relationship between latent spaces than `dat_highsim`.

## Testing and CI

Tests are configured using `testthat`.

- Test entrypoint: `tests/testthat.R`
- Package test runner: `tests/testthat/test-main.R`
- Main tests: `tests/testthat.R`
  - Smoke tests ensuring that:
    - `cv.learner()` works sequentially and in parallel
    - `learner()` and `dlearner()` run without error
  - Edge-case coverage:
    - missing entries in `Y_target` for `learner()` and `cv.learner()`
    - multiple sources via `Y_source` as a list
    - non-uniform `source_weights`
  - Regression checks:
    - the numeric values of `learner_estimate[1:5, 1:5]` and `dlearner_estimate[1:5, 1:5]` match the README-documented outputs within `1e-5`.

GitHub Actions workflows:

- `.github/workflows/R-CMD-check.yaml`: runs `R CMD check` on multiple OS/R versions.
- `.github/workflows/test-coverage.yaml`: runs coverage via `covr` and uploads to Codecov.

## Key Takeaways

- `learner()` implements LEARNER's latent-subspace transfer penalties to adaptively borrow strength from the source toward the target, and supports `NA` entries in the target matrix.
- `cv.learner()` selects `(lambda_1, lambda_2)` using the paper's entrywise k-fold cross-validation scheme (default `n_folds = 4`) to adapt to heterogeneity and reduce negative transfer.
- `dlearner()` implements the paper's direct projection estimator under shared latent-subspace assumptions and requires a fully observed `Y_target` (no missing values).
- The repository includes small simulated datasets and tests designed to guard both correctness (smoke tests) and example consistency (hardcoded regression checks).

## Supplementary Extensions (Paper Additional Context)

The supplementary material describes several extensions beyond the main-text setup; the items below are relevant context for interpreting/using the methods.

### Row- and Column-Space Specific Penalties

The main text uses a single penalty `lambda_1` for mismatch in both latent row and latent column subspaces. The supplement describes an extension where these can be different:

`lambda_{1,1}` penalizes mismatch in the latent row/genotypic space and `lambda_{1,2}` penalizes mismatch in the latent column/phenotypic space, leading to an objective of the same form as LEARNER but with separate coefficients on the two `P_perp` terms.

This improves flexibility when similarity differs substantially between row and column subspaces. (In this R package, `learner()` currently uses a single `lambda_1` coefficient; the extension would require an API/implementation change to expose `lambda_{1,1}` and `lambda_{1,2}`.)

### Multiple Source Populations

For `K > 1` sources, the supplement distinguishes:

1. Homogeneous sources (shared latent subspaces): source projection information can be pooled using weights `w_k`, forming pooled projection matrices `P(bar U_K) = sum_k w_k * U_k U_k^T` and `P(bar V_K) = sum_k w_k * V_k V_k^T`, and then running LEARNER/D-LEARNER with those pooled projections.
2. Heterogeneous sources (different latent subspaces): a more general extension assigns separate penalty parameters `lambda_{1,k}` to each source, which is more computationally demanding and not equivalent to a simple pooled projection.

The current implementation's multi-source support is consistent with the homogeneous/pooled-projection case: it uses `source_weights` to form a weighted average of projection matrices when applying the orthogonal-complement penalties. (The heterogeneous case with separate `lambda_{1,k}` per source is described in the supplement, but is not represented in the current function interface.)

### Selecting Penalties via an External Dataset

The main text selects `(lambda_1, lambda_2)` via held-out entries of `Y_target` (entrywise k-fold CV), which can perform sub-optimally under correlated noise.

The supplement describes an alternative: if an external dataset `Y_0^{ext}` is available that follows the same data-generating distribution as the target, one can evaluate each candidate `(lambda_1, lambda_2)` using the MSE on the non-missing entries of `Y_0^{ext}` and choose the pair with the smallest external-dataset MSE. This avoids the correlation between held-out and non-held-out entries that can degrade CV under correlated noise.

This external-dataset selection strategy is described in the supplement but is not exposed directly in the current R API (the `cv.learner()` function focuses on entrywise held-out CV).

## Reviewer-Driven Clarifications and Scope

Several reviewer/editor comments motivated clarification of the method's scientific framing and explicit discussion of practical caveats and extensions. The main themes relevant to this codebase are:

1. Scientific context and the "why transfer learning?" problem

   The method is motivated by constructing a cross-population atlas of low-rank structure (e.g., genetic association patterns) when a target population is underrepresented or noisier than a related source population. The key scientific challenge is heterogeneity between populations: population-specific low-rank fits can miss latent structure that is present but noisy in the target, while naive pooling can induce negative transfer.

2. Nonconvex optimization and lack of formal guarantees (empirical scope)

   The LEARNER objective is nonconvex, and the alternating gradient-based solver is used as a scalable local-search heuristic. The project-level documentation emphasizes empirical performance and does not provide formal identifiability or consistency guarantees for the alternating solver under the specific projection-penalized objective.

3. Penalty design choices and guidance via cross-validation

   In the main method, a single `lambda_1` is used for both row-space and column-space mismatch penalties, and `lambda_2` is used to mitigate scale/local-minima issues between the learned factors.

   The factorization `U V^T` is not unique (for example, simultaneous rescaling of `U` and `V` can leave the product unchanged). The `lambda_2` regularizer encourages the two factors to have comparable Gram matrices (`U^T U` vs `V^T V`), improving numerical stability and reducing degenerate scalings, while the resulting matrix estimate is the primary object of inference.

   Reviewers asked whether row/column penalties should be asymmetric (e.g., `lambda_U != lambda_V`) and how to scale them, especially when `p != q`. The supplement documents a straightforward extension to row- and column-specific penalties (`lambda_{1,1}` and `lambda_{1,2}`), but the current R API uses a single `lambda_1`. In practice, the recommended approach is to use a broad grid for `(lambda_1, lambda_2)` and rely on entrywise cross-validation to choose values that work for the specific dimension/rank/alignment/SNR regime.

4. Rank mis-specification (unequal `r_source` vs `r_target`)

   The paper supplements a discussion and simulations for unequal ranks between source and target. Broadly, overestimating the rank (e.g., using `r = max(r0, r1)`) is typically less harmful than underestimating, because underestimation can exclude nonzero latent components of `Theta_0`.

   In this R implementation, you can pass `r_source` and `r_target` separately when you have reason to expect different effective ranks. However, cross-validation in `cv.learner()` selects only `(lambda_1, lambda_2)`; rank is fixed by the provided inputs (or by ScreeNOT when ranks are missing).

5. Multiple sources and preventing a poor source from dominating

   Reviewers asked how to combine multiple sources while protecting against a noisy/misaligned source dominating the transfer. The supplement and responses distinguish:

   - Homogeneous sources (shared latent subspaces): pooled projection information can be combined using weights `w_k`, where weights proportional to relative precision (often approximated by sample size or inverse noise variance) help prevent a poor-quality source from degrading the pooled subspace estimate.
   - Heterogeneous sources (different latent subspaces): a more flexible extension can assign source-specific penalties (e.g., `lambda_{1,k}`) so that cross-validation can effectively downweight misaligned sources; this is described in the supplement but is not part of the current R interface.

   The current code implements the pooled/homogeneous style via the `source_weights` argument: when `Y_source` is a list, the orthogonal-complement projections used in the LEARNER objective are weighted and combined based on `source_weights`.

6. Related approaches and penalty interpretation (subspace vs factor matching)

   Reviewers requested brief comparison to other methods that penalize differences between subspaces directly (e.g., via Grassmann-manifold formulations or projection-based discrepancies). LEARNER's central idea is to penalize subspace mismatch through projection-orthogonal-complement terms rather than directly matching singular vectors, making transfer more robust to sign/order ambiguities.

7. Uncertainty quantification

   Reviewers asked whether standard errors/confidence regions could be attached to `Theta_hat`. The responses (and this documentation) treat uncertainty quantification as challenging and beyond the current scope of the R implementation.

