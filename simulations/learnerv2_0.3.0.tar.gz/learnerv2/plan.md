# Plan: Row-/Column-Space Specific Penalties for LEARNER

Goal: update the R package so `learner()` can use *separate* nuisance penalties for mismatches in the **latent row/genotypic** subspace vs the **latent column/phenotypic** subspace (paper’s `lambda_{1,1}` and `lambda_{1,2}`).

This extension should:
1. Preserve backward compatibility (existing `lambda_1`/`lambda_2` behavior continues to work).
2. Apply the row-penalty to the `U`-side projection complement term only, and the column-penalty to the `V`-side projection complement term only.
3. Extend `cv.learner()` so it can select `(lambda_{1,1}, lambda_{1,2}, lambda_2)` from data (with a sensible interface and clear documentation of the computational cost).

---

## 1. Current State (Where Changes Will Land)

### `R/learner.R`
The shared penalty `lambda1` is currently used in:
- Objective `f()`:
  - `t2 <- lambda1 * || P_perp_U ||_F^2` (row/genotypic penalty)
  - `t3 <- lambda1 * || P_perp_V ||_F^2` (column/phenotypic penalty)
- Gradients:
  - `f_prime_u()` uses `lambda1` in the `U` penalty term
  - `f_prime_v()` uses `lambda1` in the `V` penalty term

### `R/cv_learner.R`
`cv.learner()` currently grid-searches over `(lambda_1, lambda_2)` and parallelizes across candidate pairs. It passes `lambda1`/`lambda2` into a CV helper that calls `learner_helper()` directly (bypassing `learner()`).

---

## 2. Proposed API Extension (Backward Compatible)

### Option A (recommended): Keep `lambda_1` but add new arguments
Add two new parameters to `learner()`:
- `lambda_1_row` (maps to paper’s `lambda_{1,1}`)
- `lambda_1_col` (maps to paper’s `lambda_{1,2}`)

Backward compatibility rules:
1. Preserve the existing `learner()` behavior and calling pattern when the user only provides `lambda_1` and `lambda_2` (as done in current tests and README examples).
2. Add `lambda_1_row` and `lambda_1_col` as optional arguments with defaults that trigger the tied-penalty mode when they are not provided.
3. Implementation should follow:
   - If `lambda_1_row` and `lambda_1_col` are both missing/NULL: set them equal to `lambda_1` (tied mode).
   - If both `lambda_1_row` and `lambda_1_col` are provided: use them and do not use `lambda_1` in the objective.
4. Validation:
   - In tied mode, keep existing `lambda_1` scalar validation semantics.
   - In separate mode, validate `lambda_1_row` and `lambda_1_col` are scalars.

To keep the API ergonomic in separate-penalty mode, the implementation can make `lambda_1` optional (e.g., default `NULL`) so callers can supply only `lambda_1_row`/`lambda_1_col`. Existing callers that pass `lambda_1` continue to behave identically.

### Signature/compatibility placement detail (important)
To avoid breaking any positional-argument usage, append `lambda_1_row` and `lambda_1_col` *after* existing `learner()` arguments (i.e., do not insert them in the middle of the current signature). Since the current signature order is:
`(Y_source, Y_target, r_target, lambda_1, lambda_2, step_size, r_source, source_weights, control)`,
adding new args at the end minimizes the chance of positional calls breaking.

Similarly extend `cv.learner()`:
- add `lambda_1_row_all` and `lambda_1_col_all`
- keep old `lambda_1_all` as an alias for the special case where row/col penalties are tied

Backward compatibility rules for CV:
1. If old `lambda_1_all` is provided but not `lambda_1_row_all`/`lambda_1_col_all`, run a 2D grid like today:
   - candidates `(lambda_1, lambda_2)` where `lambda_1_row=lambda_1_col=lambda_1`
2. If `lambda_1_row_all` and `lambda_1_col_all` are provided, run a 3D grid:
   - candidates `(lambda_1_row, lambda_1_col, lambda_2)`

Similarly, make `lambda_1_all` optional (e.g., default `NULL`) so separate-mode callers can provide only `lambda_1_row_all`/`lambda_1_col_all` without dummy values.

---

## 3. Objective and Gradient Updates in `R/learner.R`

Change the plumbing so the objective and gradients accept two separate penalties.

Current wiring to respect (in this codebase):
- `learner()` passes a single scalar `lambda1` into `learner_helper()`
- `learner_helper()` passes `lambda1` into `f()` and into the gradients `f_prime_u()` / `f_prime_v()`
So the implementation should thread both `lambda1_row` and `lambda1_col` through this same call chain, using `lambda1_row` for the `U`-side penalty term and `lambda1_col` for the `V`-side penalty term. `lambda2` stays unchanged.

### Objective `f()`
Update to:
- row/genotypic penalty term:
  - `t2 <- lambda1_row * || P_perp_U ||_F^2`
- column/phenotypic penalty term:
  - `t3 <- lambda1_col * || P_perp_V ||_F^2`

The data-fit term scaling by `perc_nonmissing` for missing-data handling should remain unchanged.

### Gradients
- `f_prime_u()` should multiply the `U`-side penalty term by `lambda1_row`
- `f_prime_v()` should multiply the `V`-side penalty term by `lambda1_col`

### Multi-source interaction
No structural change is needed: `apply_P_perp_basis_list()` already produces the orthogonal-complement action for both `U` and `V`. The only difference is which scalar multiplies each side’s penalty term.

---

## 4. Cross-Validation Changes in `R/cv_learner.R`

### Grid search logic
Current logic:
- loops over `lambda_1_all` and `lambda_2_all`

New logic:
1. If using tied penalties (old behavior): same 2D grid as before.
2. If using separate penalties (new behavior): triple loop over:
   - `lambda_1_row_all`
   - `lambda_1_col_all`
   - `lambda_2_all`

### Parallelization strategy
Parallelize over candidate combinations similarly to the current implementation:
- when triple-grid is active, keep parallelization over the outer loops (e.g., parallelize across `(lambda_1_row, lambda_1_col)` and loop over `lambda_2` sequentially within each worker, or vice versa).

Document that runtime can scale quickly with the product of grid sizes.

Implementation detail to match current code:
- `cv.learner()` currently calls `cv.learner_helper()`, which in turn calls `learner_helper()` directly (bypassing `learner()`).
- so the CV refactor must thread `lambda1_row` and `lambda1_col` through both `cv.learner_helper()` and the `learner_helper()`/`f()` call chain.

### Output fields
Current return includes:
- `lambda_1_min`, `lambda_2_min`, `mse_all`, `r`

Proposed return changes:
- In tied-penalty mode: keep the old names (`lambda_1_min`, `lambda_2_min`) for compatibility with existing users/tests.
- In separate-penalty mode:
  - return `lambda_1_row_min`, `lambda_1_col_min`, and `lambda_2_min`
  - for `mse_all`, prefer a 3D array:
    `mse_all[i_row, i_col, i_2]` corresponding to the grid index order
  - for `lambda_1_min`: either omit it in separate mode or set it to `NA` (pick one and document; tied mode will remain unchanged).

---

## 5. Documentation Updates

Update roxygen docs + man pages for:
- `learner()`:
  - add parameters `lambda_1_row`, `lambda_1_col`
  - describe defaulting/tied behavior when `lambda_1` is used
  - add details matching the paper’s interpretation
- `cv.learner()`:
  - add `lambda_1_row_all`, `lambda_1_col_all`
  - explain tied vs separate modes and computational cost

Also consider whether `README.Rmd` examples should remain unchanged (recommended for minimal churn) and optionally add a short example for the new feature.

---

## 6. Testing Plan

### Backward compatibility tests
Add tests that when:
- `lambda_1_row = lambda_1_col = lambda_1`
the results match the existing behavior (within tight tolerance) for both:
- `learner()`
- `cv.learner()` using small grids

### New feature smoke tests
Add small-grid tests to ensure:
- `learner()` runs when separate penalties are provided
- `cv.learner()` can select in separate-penalty mode for a tiny grid (so CI runtime stays reasonable)

### Parallel loop globals (lint/test stability)
If you add a third `foreach` loop, update `R/globals.R` to declare the new loop index variables (e.g., `lambda_1_row_ind`, `lambda_1_col_ind`) so NOTE suppression works like the existing `lambda_1_ind` / `lambda_2_ind` setup.

---

## 7. Known Trade-offs / Risks

1. Computational cost: separate penalties increase grid dimensionality (2D -> 3D). Default guidance should recommend small grids, or tying row/col penalties unless needed.
2. User confusion risk: ambiguous inputs (`lambda_1` vs `lambda_1_row`/`lambda_1_col`) must be handled explicitly (prefer error if both are provided).
3. `mse_all` shape: changing return object structure in new mode must be documented.

---

## 8. Concrete File Checklist

Expected touched files (when you implement):
- `R/learner.R` (API signature, objective and gradient plumbing)
- `R/cv_learner.R` (CV signature + grid search + return)
- `R/globals.R` (update any new globals if needed)
- `tests/testthat/test-main.R` (compat + new tests)
- `man/learner.Rd`, `man/cv.learner.Rd` (after roxygen rebuild)
- `README.Rmd` / `README.md` (optional example)

