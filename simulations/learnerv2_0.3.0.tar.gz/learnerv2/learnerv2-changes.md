# learnerv2-changes.md

Summary of recent `learnerv2` package updates (for downstream simulation work).

Version note: these changes correspond to `learnerv2` version `0.3.0` (as reflected in the package `.tar.gz` artifact filename).

## What changed

### Separate row/column latent-subspace penalties in `learner()`
`learner()` now supports *two* nuisance penalties rather than a single shared penalty:

- `lambda_1_row` (paper: `lambda_{1,1}`) multiplies the penalty term on the `U`/row/genotypic-side projection complement.
- `lambda_1_col` (paper: `lambda_{1,2}`) multiplies the penalty term on the `V`/column/phenotypic-side projection complement.

Implementation detail: the optimization objective/gradients were updated so the objective contains `lambda_1_row * ||P_perp(U)||_F^2 + lambda_1_col * ||P_perp(V)||_F^2`, and the corresponding gradient penalty components are scaled by the same row/col scalars.

### Backward compatibility (tied-penalty mode)
Existing behavior is preserved:

- `lambda_1` remains supported (and is used as the tied value for both row and column penalties).
- If you call `learner(..., lambda_1 = L, lambda_2 = M, ...)` and do **not** provide `lambda_1_row`/`lambda_1_col`, then internally:
  - `lambda_1_row = L`
  - `lambda_1_col = L`

New behavior:
- `learner(..., lambda_1_row = Lr, lambda_1_col = Lc, lambda_2 = M, ...)` uses `Lr` and `Lc` separately.
- Providing `lambda_1` together with both `lambda_1_row` and `lambda_1_col` triggers an error (ambiguity avoidance).

## Cross-validation: `cv.learner()`

`cv.learner()` now supports two modes depending on which lambda grid inputs you provide.

### 1) Tied mode (old 2D grid; backward compatible)
Use:
- `lambda_1_all` (2D grid for the tied penalty)
- `lambda_2_all`

Behavior:
- The CV search is a 2D grid over `(lambda_1, lambda_2)`.
- Internally, for each candidate `lambda_1`, it evaluates with `lambda_1_row = lambda_1_col = lambda_1`.

Return fields in tied mode:
- `lambda_1_min` (tied lambda)
- `lambda_2_min`
- `lambda_1_row_min` = `NA`
- `lambda_1_col_min` = `NA`
- `mse_all`: same shape as before (matrix after internal transpose)
- `r`

### 2) Separate mode (new 3D grid)
Use:
- `lambda_1_row_all`
- `lambda_1_col_all`
- `lambda_2_all`

Behavior:
- CV evaluates a 3D grid over `(lambda_1_row, lambda_1_col, lambda_2)`.
- Parallelization remains supported; the implementation loops over grid combinations and calls the internal CV helper with the correct `(lambda_1_row, lambda_1_col, lambda_2)` for each fold.

Return fields in separate mode:
- `lambda_1_min` = `NA` (not applicable because row/col lambdas differ)
- `lambda_2_min`
- `lambda_1_row_min` (selected best row penalty)
- `lambda_1_col_min` (selected best col penalty)
- `mse_all`: **3D array** with dimensions:
  - `[length(lambda_1_row_all), length(lambda_1_col_all), length(lambda_2_all)]`
- `r`

## Tests / verification

- `devtools::test()` now passes (increased to 14 passing tests).
- A new unit test checks that tied penalties match separate penalties when:
  - `lambda_1_row = lambda_1_col = lambda_1`
- The README/docression numeric check for `learner(..., lambda_1 = 100, lambda_2 = 1, ...)` remains consistent (i.e., the old output values are unchanged in tied mode).

## Notes for simulation-agent authors

When designing simulation scripts:
- If you want “paper main-text” LEARNER behavior, use tied mode via `lambda_1` / `lambda_1_all`.
- If you want the supplementary “row/column-specific penalties” extension, use separate mode:
  - `learner(..., lambda_1_row = ..., lambda_1_col = ..., lambda_2 = ...)`
  - `cv.learner(..., lambda_1_row_all = ..., lambda_1_col_all = ..., lambda_2_all = ...)`

Be aware:
- separate-mode CV cost scales with `len(lambda_1_row_all) * len(lambda_1_col_all) * len(lambda_2_all)`.

