#' Latent space-based transfer learning
#'
#' This function applies the Direct project LatEnt spAce-based tRaNsfer lEaRning (D-LEARNER) method (McGrath et al. 2024) to leverage data from a source population to improve
#' estimation of a low rank matrix in an underrepresented target population.
#'
#' @param Y_target matrix containing the target population data
#' @param Y_source matrix, or list of matrices (multiple source populations). If a list, rank is determined from the first element and the latent spaces are combined across sources.
#' @param source_weights (optional) numeric vector of weights for each source when \code{Y_source} is a list. Must have length equal to the number of sources; will be normalized to sum to 1. If \code{NULL}, equal weights are used.
#' @param r (optional) integer specifying the rank. By default, ScreeNOT (Donoho et al. 2023) is applied to the first source (or the single source) to select the rank.
#'
#' @return A list with the following components:
#' \item{dlearner_estimate}{matrix containing the D-LEARNER estimate of the target population knowledge graph.}
#' \item{r}{rank value used.}
#'
#' @details
#'
#' \strong{Data and notation:}
#'
#' The data consists of a matrix in the target population \eqn{Y_0 \in \mathbb{R}^{p \times q}} and the source population \eqn{Y_1 \in \mathbb{R}^{p \times q}}.
#' Let \eqn{\hat{U}_{k} \hat{\Lambda}_{k} \hat{V}_{k}^{\top}} denote the truncated singular value decomposition (SVD) of \eqn{Y_k}, \eqn{k = 0, 1}.
#'
#' For \eqn{k = 0, 1}, one can view \eqn{Y_k} as a noisy version of \eqn{\Theta_k}, referred to as the knowledge graph. The target of inference is the target population knowledge graph, \eqn{\Theta_0}.
#'
#' \strong{Estimation:}
#'
#' This method estimates \eqn{\Theta_0} by \eqn{\hat{U}_{1}^{\top}\hat{U}_{1} Y_0 \hat{V}_{1}^{\top}\hat{V}_{1}}.
#'
#' @references
#' Donoho, D., Gavish, M. and Romanov, E. (2023). \emph{ScreeNOT: Exact MSE-optimal singular value thresholding in correlated noise}. The Annals of Statistics, 51(1), pp.122-148.
#'
#' @examples
#' res <- dlearner(Y_source = dat_highsim$Y_source,
#'                 Y_target = dat_highsim$Y_target)
#'
#' @export

dlearner <- function(Y_source, Y_target, source_weights = NULL, r){
  is_list <- is.list(Y_source) && !is.matrix(Y_source)
  if (is_list){
    if (length(Y_source) < 1L) stop('Y_source list must have at least one element.')
    Y_ref <- Y_source[[1]]
    if (!is.matrix(Y_ref)) stop('Each element of Y_source must be a matrix.')
    for (k in seq_along(Y_source)){
      if (!identical(dim(Y_source[[k]]), dim(Y_target)))
        stop('All source matrices and Y_target must have the same dimensions.')
      if (any(is.na(Y_source[[k]])))
        stop('Source matrices cannot contain NA values.')
    }
    if (!is.null(source_weights)){
      if (length(source_weights) != length(Y_source))
        stop('source_weights must have length equal to the number of sources.')
      source_weights <- as.numeric(source_weights) / sum(source_weights)
    } else {
      source_weights <- rep(1 / length(Y_source), length(Y_source))
    }
  } else {
    Y_ref <- Y_source
    if (!identical(dim(Y_source), dim(Y_target)))
      stop('Y_source and Y_target must have the same dimensions')
    if (any(is.na(Y_source)))
      stop('Y_source cannot have NA values.')
    source_weights <- 1
  }
  if (any(is.na(Y_target)))
    stop('Y_target cannot have NA values')

  p <- nrow(Y_ref)
  q <- ncol(Y_ref)

  if (missing(r)){
    max_rank <- min(p, q) / 3
    r <- max(ScreeNOT::adaptiveHardThresholding(Y = Y_ref, k = max_rank)$r, 1)
  }

  ## Build U_basis_list and V_basis_list (one SVD per source)
  if (is_list){
    K <- length(Y_source)
    U_basis_list <- vector('list', K)
    V_basis_list <- vector('list', K)
    for (k in seq_len(K)){
      svd_k <- svd(Y_source[[k]], nu = r, nv = r)
      U_basis_list[[k]] <- svd_k$u
      V_basis_list[[k]] <- svd_k$v
    }
  } else {
    svd_source <- svd(Y_source, nu = r, nv = r)
    U_basis_list <- list(svd_source$u)
    V_basis_list <- list(svd_source$v)
  }

  ## P_avg_U Y = sum_k w_k U_k (U_k' Y); then result = (P_avg_U Y) P_avg_V = sum_j w_j (Y_mid V_j) V_j'
  K <- length(U_basis_list)
  Y_mid <- Reduce('+', mapply(function(Uk, wk) wk * (Uk %*% crossprod(Uk, Y_target)), U_basis_list, source_weights, SIMPLIFY = FALSE))
  dlearner_estimate <- Reduce('+', mapply(function(Vk, wk) wk * ((Y_mid %*% Vk) %*% t(Vk)), V_basis_list, source_weights, SIMPLIFY = FALSE))

  colnames(dlearner_estimate) <- colnames(Y_ref)
  rownames(dlearner_estimate) <- rownames(Y_ref)

  return(list(dlearner_estimate = dlearner_estimate, r = r))
}

