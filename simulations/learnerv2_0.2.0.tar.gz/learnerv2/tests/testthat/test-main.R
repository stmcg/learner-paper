test_that("cv.learner (sequential) does not fail", {
  expect_no_error(
    cv.learner(Y_source = dat_highsim$Y_source,
               Y_target = dat_highsim$Y_target,
               lambda_1_all = c(1, 10),
               lambda_2_all = c(1, 10),
               step_size = 0.003))
})

test_that("cv.learner (parallel) does not fail", {
  expect_no_error(
    cv.learner(Y_source = dat_highsim$Y_source,
               Y_target = dat_highsim$Y_target,
               lambda_1_all = c(1, 10),
               lambda_2_all = c(1, 10),
               step_size = 0.003,
               n_cores = 2))
})

test_that("learner does not fail", {
  expect_no_error(
    learner(Y_source = dat_highsim$Y_source,
            Y_target = dat_highsim$Y_target,
            lambda_1 = 1, lambda_2 = 1,
            step_size = 0.003))
})

test_that("dlearner does not fail", {
  expect_no_error(
    dlearner(Y_source = dat_highsim$Y_source,
             Y_target = dat_highsim$Y_target))
})


# Missing data cases
set.seed(1234)
Y_target_highsim_missing <- dat_highsim$Y_target
Y_target_highsim_missing[round(runif(100, 1, 100 * 50))] <- NA

test_that("learner does not fail with missing data", {
  expect_no_error(
    learner(Y_source = dat_highsim$Y_source,
            Y_target = Y_target_highsim_missing,
            lambda_1 = 1, lambda_2 = 1,
            step_size = 0.003))
})

test_that("cv.learner does not fail with missing data", {
  expect_no_error(
    cv.learner(Y_source = dat_highsim$Y_source,
               Y_target = Y_target_highsim_missing,
               lambda_1_all = c(1, 10),
               lambda_2_all = c(1, 10),
               step_size = 0.003))
})

# Multiple source populations (Y_source as list)
test_that("learner accepts list of source matrices", {
  Y_sources <- list(dat_highsim$Y_source, dat_highsim$Y_source + 0.1 * rnorm(length(dat_highsim$Y_source)))
  expect_no_error(
    learner(Y_source = Y_sources,
            Y_target = dat_highsim$Y_target,
            lambda_1 = 1, lambda_2 = 1,
            step_size = 0.003))
})

test_that("cv.learner accepts list of source matrices", {
  Y_sources <- list(dat_highsim$Y_source, dat_highsim$Y_source + 0.1 * rnorm(length(dat_highsim$Y_source)))
  expect_no_error(
    cv.learner(Y_source = Y_sources,
               Y_target = dat_highsim$Y_target,
               lambda_1_all = c(1, 10),
               lambda_2_all = c(1, 10),
               step_size = 0.003))
})

test_that("dlearner accepts list of source matrices", {
  Y_sources <- list(dat_highsim$Y_source, dat_highsim$Y_source + 0.1 * rnorm(length(dat_highsim$Y_source)))
  expect_no_error(
    dlearner(Y_source = Y_sources,
             Y_target = dat_highsim$Y_target))
})

test_that("source_weights work for list of sources", {
  set.seed(123)
  Y_sources <- list(dat_highsim$Y_source, dat_highsim$Y_source + 0.1 * rnorm(length(dat_highsim$Y_source)))
  expect_no_error(
    learner(Y_source = Y_sources,
            Y_target = dat_highsim$Y_target,
            source_weights = c(0.7, 0.3),
            lambda_1 = 1, lambda_2 = 1,
            step_size = 0.003))
  expect_no_error(
    dlearner(Y_source = Y_sources,
             Y_target = dat_highsim$Y_target,
             source_weights = c(2, 1)))
})

# README example: output [1:5, 1:5] matches documented values
test_that("learner output [1:5, 1:5] matches README", {
  res_learner <- learner(Y_source = dat_highsim$Y_source,
                         Y_target = dat_highsim$Y_target,
                         lambda_1 = 100, lambda_2 = 1,
                         step_size = 0.003)
  expected_learner <- matrix(c(
    0.1468889, -1.63414688, 1.1857308, 0.008093962, 0.2196070,
    0.1087766, -0.24392770, -1.0061737, -0.058119721, -0.4012974,
    -0.6213028, 1.04206753, -0.6907776, 0.905709331, -0.5324437,
    1.5811588, -3.00001490, 0.3978080, -2.124285120, 0.6909386,
    0.5046133, 0.01845138, -1.4798209, -0.765601712, -0.2230227
  ), 5, 5, byrow = TRUE)
  expect_equal(res_learner$learner_estimate[1:5, 1:5], expected_learner, tolerance = 1e-5)
})

test_that("dlearner output [1:5, 1:5] matches README", {
  res_dlearner <- dlearner(Y_source = dat_highsim$Y_source,
                           Y_target = dat_highsim$Y_target)
  expected_dlearner <- matrix(c(
    0.0959171, -1.72143637, 1.15500149, 0.005478273, 0.3258085,
    0.1077137, -0.32243480, -1.03557177, -0.108195636, -0.4093049,
    -0.7237275, 0.86634922, -0.43528206, 1.105802194, -0.5961351,
    1.6347696, -2.91985925, 0.04876288, -2.357504089, 0.8127403,
    0.4757450, 0.05665543, -1.50373470, -0.744076401, -0.2876033
  ), 5, 5, byrow = TRUE)
  expect_equal(res_dlearner$dlearner_estimate[1:5, 1:5], expected_dlearner, tolerance = 1e-5)
})
